import Link from 'next/link'
export default function Home(){
  return (
    <div className="p-6">
      <h1 className="text-2xl mb-4">Lovable Starter — Projects</h1>
      <div className="grid grid-cols-3 gap-4">
        <Link href="/project/demo"><a className="p-4 border rounded">Demo Project</a></Link>
      </div>
    </div>
  )
}

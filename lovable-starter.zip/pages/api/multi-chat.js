import axios from 'axios'

export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).end()
  const { prompt, projectId, models } = req.body
  // Basic validation
  if(!prompt) return res.status(400).json({ error: 'no prompt' })
  // If no real AI key provided, return a stubbed response
  const AIML_API_KEY = process.env.AIML_API_KEY
  if(!AIML_API_KEY){
    // return simple echoed responses for each model
    const outputs = (models || ['gpt-4o']).map(m => ({ model: m, ok: true, text: `Stubbed response from ${m}: ${prompt.slice(0,200)}` }))
    return res.json({ ok: true, outputs, remaining: 9999 })
  }

  const ENDPOINT = 'https://api.aimlapi.com/chat/completions'
  const requests = (models || ['gpt-4o']).map(m =>
    axios.post(ENDPOINT, {
      model: m,
      messages: [{ role: 'user', content: prompt }]
    }, { headers: { Authorization: `Bearer ${AIML_API_KEY}` } })
  )
  try{
    const results = await Promise.allSettled(requests)
    const outputs = results.map((r, idx) => {
      if(r.status === 'fulfilled'){
        const text = r.value.data?.choices?.[0]?.message?.content || JSON.stringify(r.value.data)
        return { model: models[idx], ok: true, text }
      }
      return { model: models[idx], ok: false, text: r.reason?.message || 'error' }
    })
    return res.json({ ok: true, outputs, remaining: 0 })
  }catch(e){
    return res.status(500).json({ error: e.message })
  }
}

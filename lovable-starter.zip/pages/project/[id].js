import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'
const EditorWrapper = dynamic(() => import('../../components/EditorWrapper'), { ssr: false })
import Chatbox from '../../components/Chatbox'

export default function ProjectPage(){
  const router = useRouter()
  const { id } = router.query
  return (
    <div className="p-6 grid grid-cols-3 gap-4">
      <div className="col-span-2">
        <h2 className="text-xl mb-2">Project: {id}</h2>
        <EditorWrapper projectId={id} />
      </div>
      <div>
        <Chatbox projectId={id} userId={"demo-user"} />
      </div>
    </div>
  )
}

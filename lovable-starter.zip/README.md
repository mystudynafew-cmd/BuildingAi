# Lovable-style Starter (Minimal)

## Quick start
1. Copy `.env.local.example` to `.env.local` and fill keys.
2. `npm install`
3. `npm run dev`

## Notes
- This is a minimal starter implementing project pages, a chatbox UI, and an API route `api/multi-chat`.
- Replace AIML_API_KEY in `.env.local` when using a real AI provider.

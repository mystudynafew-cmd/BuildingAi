import dynamic from 'next/dynamic'
import { useEffect, useState } from 'react'
const MonacoEditor = dynamic(() => import('@monaco-editor/react'), { ssr: false })

export default function EditorWrapper({ projectId }){
  const [code, setCode] = useState('// start coding...\nconsole.log("hello world")')
  useEffect(() => {
    // placeholder: in real app fetch file from supabase
  }, [projectId])

  return (
    <div className="h-[70vh] border rounded">
      <MonacoEditor height="70vh" defaultLanguage="javascript" value={code} onChange={v => setCode(v)} />
    </div>
  )
}

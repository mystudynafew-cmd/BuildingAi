import { useState } from 'react'
import axios from 'axios'

export default function Chatbox({ projectId, userId }){
  const [prompt, setPrompt] = useState('')
  const [loading, setLoading] = useState(false)
  const [messages, setMessages] = useState([])

  async function send(){
    if(!prompt) return
    setLoading(true)
    try{
      const models = ['gpt-4o','mistral']
      const r = await axios.post('/api/multi-chat', { prompt, projectId, models })
      const outs = r.data.outputs
      const newMsgs = outs.map(o => ({ id: Math.random(), model: o.model, text: o.text }))
      setMessages(prev => [...prev, { id: Math.random(), role: 'user', text: prompt }, ...newMsgs])
      setPrompt('')
    }catch(e){
      console.error(e)
      alert(e.response?.data?.error || e.message)
    }finally{ setLoading(false) }
  }

  return (
    <div className="p-4 border rounded">
      <div className="h-64 overflow-auto mb-4">
        {messages.map(m => (
          <div key={m.id} className="mb-3">
            <div className="text-sm text-gray-500">{m.model || m.role}</div>
            <div className="bg-gray-100 p-2 rounded">{m.text}</div>
          </div>
        ))}
      </div>
      <textarea value={prompt} onChange={e => setPrompt(e.target.value)} className="w-full p-2 border rounded" />
      <div className="flex gap-2 mt-2">
        <button onClick={send} disabled={loading} className="px-4 py-2 bg-blue-600 text-white rounded">Send</button>
        <div className="self-center text-sm text-gray-500">{loading ? 'Thinking...' : ''}</div>
      </div>
    </div>
  )
}
